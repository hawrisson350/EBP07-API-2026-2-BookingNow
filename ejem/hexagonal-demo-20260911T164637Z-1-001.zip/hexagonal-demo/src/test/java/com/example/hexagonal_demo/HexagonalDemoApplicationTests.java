package com.example.hexagonal_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexagonalDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
