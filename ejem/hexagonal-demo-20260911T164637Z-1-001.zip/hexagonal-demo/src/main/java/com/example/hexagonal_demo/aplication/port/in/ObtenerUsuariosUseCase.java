package com.example.hexagonal_demo.aplication.port.in;
import com.example.hexagonal_demo.domain.model.Usuario;

import java.util.List;



public interface ObtenerUsuariosUseCase {

    List<Usuario> obtenerUsuarios();

}