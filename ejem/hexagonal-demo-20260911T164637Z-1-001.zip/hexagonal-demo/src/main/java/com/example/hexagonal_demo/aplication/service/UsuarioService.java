package com.example.hexagonal_demo.aplication.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.hexagonal_demo.aplication.port.in.CrearUsuarioUseCase;
import com.example.hexagonal_demo.aplication.port.in.EliminarUsuarioUseCase;
import com.example.hexagonal_demo.aplication.port.in.ObtenerUsuarioUseCase;
import com.example.hexagonal_demo.aplication.port.in.ObtenerUsuariosUseCase;
import com.example.hexagonal_demo.aplication.port.out.UsuarioRepositoryPort;
import com.example.hexagonal_demo.domain.model.Usuario;

@Service
public class UsuarioService implements CrearUsuarioUseCase,
        EliminarUsuarioUseCase,
        ObtenerUsuariosUseCase,
        ObtenerUsuarioUseCase {

    private final UsuarioRepositoryPort usuarioRepositoryPort;

    public UsuarioService(UsuarioRepositoryPort usuarioRepositoryPort) {
        this.usuarioRepositoryPort = usuarioRepositoryPort;
    }

    @Override
    public Usuario crearUsuario(Usuario usuario) {

        if (usuario.getNombre() == null ||
            usuario.getNombre().isBlank()) {

            throw new IllegalArgumentException(
                "El nombre es obligatorio"
            );
        }

        if (usuario.getEmail() == null ||
            usuario.getEmail().isBlank()) {

            throw new IllegalArgumentException(
                "El email es obligatorio"
            );
        }

        return usuarioRepositoryPort.guardar(usuario);
    }

    @Override
    public List<Usuario> obtenerUsuarios() {
        return usuarioRepositoryPort.obtenerTodos();
    }

    @Override
    public Optional<Usuario> obtenerUsuario(Long id) {
        return usuarioRepositoryPort.obtenerPorId(id);
    }

    @Override
    public void eliminarUsuario(Long id) {
        usuarioRepositoryPort.eliminar(id);
    }
}