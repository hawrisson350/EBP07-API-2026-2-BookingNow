package com.example.hexagonal_demo.aplication.port.in;

import com.example.hexagonal_demo.domain.model.Usuario;

public interface CrearUsuarioUseCase {
    Usuario crearUsuario(Usuario usuario);
}
