package com.example.hexagonal_demo.aplication.port.in;

public interface EliminarUsuarioUseCase {
    void eliminarUsuario(Long id);
}
