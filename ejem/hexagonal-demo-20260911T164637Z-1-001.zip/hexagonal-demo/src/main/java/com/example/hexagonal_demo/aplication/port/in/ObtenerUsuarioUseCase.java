package com.example.hexagonal_demo.aplication.port.in;


import java.util.Optional;

import com.example.hexagonal_demo.domain.model.Usuario;


public interface ObtenerUsuarioUseCase {

    Optional<Usuario> obtenerUsuario(Long id);

}